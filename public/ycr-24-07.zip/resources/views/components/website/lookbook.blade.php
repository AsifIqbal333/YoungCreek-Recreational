<section class="flat-spacing-2 pt-0">
    <div class="container">
        <div class="row flat-with-text-lookbook wrap-lookbook-hover align-items-center">
            <div class="col-lg-6 col-md-6">
                <div class="banner-img">
                    <img class="lazyload" data-src="{{ asset('theme/images/section/section-discover-1.jpg') }}"
                        src="{{ asset('theme/images/section/section-discover-1.jpg') }}" alt="banner">
                    <div class="tf-pin-btn pin-1 bundle-pin-item swiper-button" data-slide="0" id="pin1">
                        <span>1</span>

                        <div class="loobook-product-wrap">
                            <div class="loobook-product">
                                <div class="img-style">
                                    <img src="{{ asset('theme/images/gallery/lookbook-3.jpg') }}" alt="img">
                                </div>
                                <div class="content">
                                    <div class="info">
                                        <a href="product-detail.html" class="text-title text-line-clamp-1 link">Double
                                            Standing Desk</a>
                                        <div class="price text-button">$69.99</div>
                                    </div>
                                    <a href="#shoppingCart" data-bs-toggle="modal" class="btn-lookbook btn-line">Add
                                        to cart</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tf-pin-btn pin-2 bundle-pin-item swiper-button" data-slide="1" id="pin2">
                        <span>2</span>

                        <div class="loobook-product-wrap">
                            <div class="loobook-product">
                                <div class="img-style">
                                    <img src="{{ asset('theme/images/gallery/lookbook-1.jpg') }}" alt="img">
                                </div>
                                <div class="content">
                                    <div class="info">
                                        <a href="product-detail.html"
                                            class="text-title text-line-clamp-1 link">Ergonomic Headrest</a>
                                        <div class="price text-button">$69.99</div>
                                    </div>
                                    <a href="#shoppingCart" data-bs-toggle="modal" class="btn-lookbook btn-line">Add
                                        to cart</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="tf-pin-btn pin-3 bundle-pin-item swiper-button" data-slide="2" id="pin3">
                        <span>3</span>

                        <div class="loobook-product-wrap">
                            <div class="loobook-product">
                                <div class="img-style">
                                    <img src="{{ asset('theme/images/gallery/lookbook-2.jpg') }}" alt="img">
                                </div>
                                <div class="content">
                                    <div class="info">
                                        <a href="product-detail.html" class="text-title text-line-clamp-1 link">Double
                                            Standing Desk</a>
                                        <div class="price text-button">$69.99</div>
                                    </div>
                                    <a href="#shoppingCart" data-bs-toggle="modal" class="btn-lookbook btn-line">Add
                                        to cart</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-6 col-md-6">
                <div class="lookbook-content">
                    <div class="box-title">
                        <h3 class="title wow fadeInUp">Unlock Amazing Savings With Our Combo Deals</h3>
                        <p class="sub-desc text-secondary  wow fadeInUp" data-wow-delay="0.1s">Enjoy special savings
                            by bundling
                            your favorite office essentials in one convenient purchase.</p>
                    </div>
                    <div class="wrap-cart-item bundle-hover-wrap mb_40">
                        <div class="cart-item bundle-hover-item pin1">
                            <h6 class="number">
                                1
                            </h6>
                            <div class="image-cart">
                                <img src="{{ asset('theme/images/shop/cart-item-1.jpg') }}" alt="">
                            </div>
                            <div class="info">
                                <h6 class="name">
                                    <a href="product-detail.html" class="link">
                                        Ergonomic Chair Pro
                                    </a>
                                </h6>
                                <h6 class="price">
                                    $33.00
                                </h6>
                            </div>
                        </div>
                        <div class="cart-item bundle-hover-item pin2">
                            <h6 class="number">
                                2
                            </h6>
                            <div class="image-cart">
                                <img src="{{ asset('theme/images/shop/cart-item-2.jpg') }}" alt="">
                            </div>
                            <div class="info">
                                <h6 class="name">
                                    <a href="product-detail.html" class="link">
                                        Laptop Stand Office
                                    </a>
                                </h6>
                                <h6 class="price">
                                    $33.00
                                </h6>
                            </div>
                        </div>
                        <div class="cart-item bundle-hover-item pin3">
                            <h6 class="number">
                                3
                            </h6>
                            <div class="image-cart">
                                <img src="{{ asset('theme/images/shop/cart-item-3.jpg') }}" alt="">
                            </div>
                            <div class="info">
                                <h6 class="name">
                                    <a href="product-detail.html" class="link">
                                        Open Box Laptop Stand
                                    </a>
                                </h6>
                                <h6 class="price">
                                    $33.00
                                </h6>
                            </div>
                        </div>
                    </div>
                    <div class="total-lb">
                        <a href="#shoppingCart" data-bs-toggle="modal" class="tf-btn btn-onsurface">
                            <span>Add Set To Cart</span>
                            <div class="discount">
                                <span class="text-button-small">$99.00</span>
                                <span class="text-body-default">79.99</span>
                            </div>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
