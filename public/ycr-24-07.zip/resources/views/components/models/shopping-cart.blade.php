<div class="modal fullRight fade modal-shopping-cart" id="shoppingCart">
    <div class="modal-dialog">
        @livewire('shopping-cart')
    </div>
</div>
