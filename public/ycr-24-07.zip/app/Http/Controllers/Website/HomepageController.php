<?php

namespace App\Http\Controllers\Website;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use App\Models\Product;
use Illuminate\Http\Request;

class HomepageController extends Controller
{
    /**
     * Handle the incoming request.
     */
    public function __invoke(Request $request)
    {
        $categories = [];
        foreach (categories() as $category) {
            $item = $category;
            if ($category['slug'] !== 'safety-surfacing-edging') {
                $productQuery = Product::query()->with('images')
                    ->select(['id', 'name', 'slug', 'type', 'category', 'sub_category', 'price'])
                    ->whereType($category['slug']);

                $item['products_count'] = $productQuery->clone()->count();
                // $item['product'] = $productQuery->clone()
                //     ->whereHas('images')
                //     ->whereHas('orders')
                //     ->withCount('orders')
                //     ->orderByDesc('orders_count')
                //     ->first();
                // if (!$item['product']) {
                //     $item['product'] = $productQuery->clone()
                //         ->with('images')
                //         ->whereHas('images')
                //         ->first();
                // }
            }

            $categories[] = $item;
        }

        $ourPicks = Product::query()
            ->with('images')
            ->has('images', '>=', 2)
            // ->whereHas('images')
            ->select(['id', 'name', 'slug', 'type', 'category', 'sub_category', 'price', 'description'])
            ->skip(7)
            ->take(8);
        $topPicks = Product::query()
            ->with('images')
            ->has('images', '>=', 2)
            // ->whereHas('images')
            ->select(['id', 'name', 'slug', 'type', 'category', 'sub_category', 'price', 'description'])
            ->whereNotIn('id', $ourPicks->pluck('id'))
            ->take(8)
            ->get();

        return view('homepage', [
            'categories' => $categories,
            'ourPicks' => $ourPicks->get(),
            'topPicks' => $topPicks
        ]);
    }
}
