<div class="tf-payment">
    <ul>
        <li>
            <img src="{{ asset('theme/images/payment/payment-1.png') }}" alt="payment-1">
        </li>
        <li>
            <img src="{{ asset('theme/images/payment/payment-2.png') }}" alt="payment-2">
        </li>
        <li>
            <img src="{{ asset('theme/images/payment/payment-3.png') }}" alt="payment-3">
        </li>
        <li>
            <img src="{{ asset('theme/images/payment/payment-4.png') }}" alt="payment-4">
        </li>
        <li>
            <img src="{{ asset('theme/images/payment/payment-5.png') }}" alt="payment-5">
        </li>
        <li>
            <img src="{{ asset('theme/images/payment/payment-6.png') }}" alt="payment-6">
        </li>
    </ul>
</div>
