@extends('layouts.website')

@section('title', 'Privacy Policy')

@section('content')
    <header class="woocommerce-products-header masthead masthead--innerpage" id="masthead">
        <h1 class="woocommerce-products-header__title page-title">Privacy Policy
        </h1>

        <div class="breadcrumbs" id="breadcrumbs"><a href="{{ route('homepage') }}">Home</a> | <span>
                Privacy Policy</span></div>
    </header>

    <x-website.trusted-sources />

    <section id="testimonials" class="testimonial-section test">
        <div class="testimonial-list-wrapper">
        </div>
    </section>

    <section class="section section--highlight">
        <div class="container container-fluid">
            <div class="page-content row">

                <article class="page-article col-xxs-12 col-sm-8 col-sm-push-2">
                    <h2 class="title--border title-light-blue"><b>Privacy Policy </b></h2>
                    <p><span style="font-weight: 400;">Protecting your private information is our priority.The statement of
                            privacy applies to YoungCreek Recreational, LLC and governs data collection and usage for
                            the purposes of this privacy policy, unless otherwise noted. YoungCreek Recreational, LLC,
                            Adventure Powder Coating, Adventure Shade Systems and </span><a
                            href="https://www.youngcreekrec.com/"><span
                                style="font-weight: 400;">youngcreekrec.com</span></a><span style="font-weight: 400;">. The
                            YoungCreek Recreational, LLC website is an e-commerce site. By using the YoungCreek Recreational, LLC website you consent
                            to the data practices described in this statement. </span></p>
                    <h3 class="title--border title-light-blue"><b>Collection of your Personal Information </b></h3>
                    <p><span style="font-weight: 400;">In order to better provide you with products and services offered on
                            our site, YoungCreek Recreational, LLC may collect personally identifiable information such as
                            your:</span></p>
                    <ul>
                        <li style="font-weight: 400;"><span style="font-weight: 400;">First and Last name </span></li>
                        <li style="font-weight: 400;"><span style="font-weight: 400;">Mailing Address</span></li>
                        <li style="font-weight: 400;"><span style="font-weight: 400;">E-mail Address </span></li>
                        <li style="font-weight: 400;"><span style="font-weight: 400;">Phone Number</span></li>
                        <li style="font-weight: 400;"><span style="font-weight: 400;">Company Information</span></li>
                    </ul>
                    <p><span style="font-weight: 400;">If you purchase YoungCreek Recreational, LLC products and services,
                            we collect customer information and payment details as well. This information is used to
                            complete the purchase transaction.</span></p>
                    <p><span style="font-weight: 400;">We do not collect any personal information about you unless you
                            voluntarily provide it to us.  However, you may be required to provide certain personal
                            information to us when you elect to use certain products or services available on the site.
                            These may include: </span></p>
                    <p><span style="font-weight: 400;">(a) registering for an account on our site</span></p>
                    <p><span style="font-weight: 400;">(b) signing up for special offers from selected third parties</span>
                    </p>
                    <p><span style="font-weight: 400;">(c) submitting a contact form</span></p>
                    <p><span style="font-weight: 400;">(d) submitting your credit card or other payment information when
                            ordering and purchasing products and services on our site. </span></p>
                    <p><span style="font-weight: 400;">To which, we will use your information for,  but not limited to,
                            communicating with you in relation to the services and/or products you have requested from us.
                            We also may request additional personal or non-personal information from you in the future.
                        </span></p>
                    <h3 class="title--border title-light-blue"><b>Use of your Personal Information </b></h3>
                    <p><span style="font-weight: 400;">YoungCreek Recreational, LLC collects and uses your personal
                            information to operate its website(s) and deliver the services you have requested. </span></p>
                    <p><span style="font-weight: 400;">YoungCreek Recreational, LLC may also use your personally
                            identifiable information to inform you of other products or services available from Adventure
                            Playground Systems and its affiliates upon your consent from data gathered while using
                            websites.</span></p>
                    <h3 class="title--border title-light-blue"><b>Sharing with Third Parties</b></h3>
                    <p><span style="font-weight: 400;">YoungCreek Recreational, LLC does not sell, rent or lease its
                            customer list to third parties.</span></p>
                    <p><span style="font-weight: 400;">YoungCreek Recreational, LLC may share data with trusted partners to
                            help perform statistical analysis, send you email or postal mail, provide customer support (ie.
                            product warranty, maintenance, etc.) or arrange for deliveries. All such third parties are
                            prohibited from using your personal information except to provide these services to Adventure
                            Playground Systems and are required to maintain the confidentiality of your information. </span>
                    </p>
                    <p><span style="font-weight: 400;">YoungCreek Recreational, LLC may disclose your personal information,
                            without notice, if required to do so by law or in the good faith belief that such action is
                            necessary to; </span></p>
                    <p><span style="font-weight: 400;">(a) conform to the edicts of the law or comply with the legal process
                            served to YoungCreek Recreational, LLC  </span></p>
                    <p><span style="font-weight: 400;">(b) protect and defend the rights or property of YoungCreek Recreational, LLC, Inc
                        </span></p>
                    <p><span style="font-weight: 400;">(c) act under exigent circumstances to protect the personal safety of
                            users of YoungCreek Recreational, LLC or the general public.</span></p>
                    <h3 class="title--border title-light-blue"><b>Tracking User Behavior </b></h3>
                    <p><span style="font-weight: 400;">YoungCreek Recreational, LLC may keep track of the website and pages
                            our users visit within YoungCreek Recreational, LLC in order to determine what products or
                            services are most popular.  This data is used to deliver customized content and advertising
                            within YoungCreek Recreational, LLC to customers whose behavior indicates that they are
                            interested in a particular subject area. </span></p>
                    <h3 class="title--border title-light-blue"><b>Automatically Collected Information </b></h3>
                    <p><span style="font-weight: 400;">Information about your computer hardware and software may be
                            automatically collected by YoungCreek Recreational, LLC.  This information can include: your IP
                            address, browser type, domain names, access times and referring website addresses. This
                            information is used for the operation of the service, to maintain quality of the service, and to
                            provide general statistics regarding use of the YoungCreek Recreational, LLC websites. </span>
                    </p>
                    <h3 class="title--border title-light-blue"><b>Links </b></h3>
                    <p><span style="font-weight: 400;">This website contains links to other sites. Please be aware that we
                            are not responsible for the content or privacy practices of such other sites. We encourage our
                            users to be aware when they leave our site and to read the privacy statement of any other site
                            that collects personally identifiable information. </span></p>
                    <h3 class="title--border title-light-blue"><b>Security of your Personal Information</b></h3>
                    <p><span style="font-weight: 400;">YoungCreek Recreational, LLC secures your personal information from
                            unauthorized access, use, or disclosure.</span></p>
                    <p><span style="font-weight: 400;">YoungCreek Recreational, LLC uses the following method for this
                            purpose:</span></p>
                    <h3 class="title--border title-light-blue"><b>SSL Protocol</b></h3>
                    <p><span style="font-weight: 400;">When personal information (such as a credit card number) is
                            transmitted to other websites, it is protected through the use of encryption, such as the Secure
                            Sockets Layer(SSL) protocol.</span></p>
                    <p><span style="font-weight: 400;">We strive to take appropriate security measure to protect against
                            unauthorized access to or alteration of your personal information. Unfortunately, no data
                            transmission over the internet or any wireless network can be guaranteed to be 100% secure. As a
                            result, while we strive to protect your personal information, you acknowledge that: </span></p>
                    <p><span style="font-weight: 400;">(a) there are security and privacy limitations inherent to the
                            internet which are beyond our control</span></p>
                    <p><span style="font-weight: 400;">(b) security, integrity and privacy of any and all information and
                            data exchanged between you and us through this site cannot be guaranteed</span></p>
                    <h3 class="title--border title-light-blue"><b>Children Under Thirteen </b></h3>
                    <p><span style="font-weight: 400;">YoungCreek Recreational, LLC does not knowingly collect personally
                            identifiable information from children under the age of thirteen. If you are under the age of
                            thirteen, you must ask your parent or guardian for permission to use the website. </span></p>
                    <h3 class="title--border title-light-blue"><b>E-mail Communications </b></h3>
                    <p><span style="font-weight: 400;">From time to time,YoungCreek Recreational, LLC may contact you via
                            email for the purpose of providing announcements, promotional offers, alerts, confirmations,
                            surveys and/or other general communication. </span></p>
                    <p><span style="font-weight: 400;">If you would like to stop receiving marketing or promotional
                            communication via email from YoungCreek Recreational, LLC, you may opt out of such communication
                            by clicking on the Unsubscribe button.</span></p>
                    <h3 class="title--border title-light-blue"><b>External Data Storage Sites </b></h3>
                    <p><span style="font-weight: 400;">We may store your personal information data on the servers provided
                            by third party hosting vendors with whom we have contracted. No Credit Card data will be stored
                            for future use.   </span></p>
                    <h3 class="title--border title-light-blue"><b>Changes to this Statement</b></h3>
                    <p><span style="font-weight: 400;">YoungCreek Recreational, LLC reserves the right to change this
                            privacy policy from time to time. We will notify you about significant changes in the way we
                            treat personal information by sending a notice to the primary email address specified in your
                            account, by placing a prominent notice on our site, and /or by updating any privacy information
                            on this page. Your continued use of the site and/or services available through this site after
                            such modifications will constitute your: </span></p>
                    <p><span style="font-weight: 400;">(a) acknowledgment of the modified privacy policy</span></p>
                    <p><span style="font-weight: 400;">(b) agreement to abide and be bound by that policy</span></p>
                    <h3 class="title--border title-light-blue"><b>Contact Information </b></h3>
                    <p><span style="font-weight: 400;">YoungCreek Recreational, LLC welcomes your questions or comments
                            regarding this statement of privacy. If you believe that YoungCreek Recreational, LLC has not
                            adhered to this statement, please contact YoungCreek Recreational, LLC at: </span></p>
                    <p><strong>By Mail Delivery:</strong></p>
                    <p><span style="font-weight: 400;">YoungCreek Recreational, LLC Inc.</span></p>
                    <p><span style="font-weight: 400;">10845 Church Lane Houston,Texas 77043</span></p>
                    <p><strong>By Email Address:</strong></p>
                    <p><span style="font-weight: 400;">chris@youngcreekrec.com </span></p>
                    <p><strong>By Telephone number:</strong></p>
                    <p><span style="font-weight: 400;"> Office: (713) 935-9684 </span></p>
                    <p><span style="font-weight: 400;">  Toll Free: (888) 935-2112 </span></p>
                    <p><span style="font-weight: 400;">Effective as of October 03, 2018   </span></p>
                </article>

            </div>
        </div>
    </section>

    <x-website.feature-industries />


@endsection
